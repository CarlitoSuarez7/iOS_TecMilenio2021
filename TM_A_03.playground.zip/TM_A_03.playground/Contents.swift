import UIKit
/*:
# Playground - Actividad 3
* Tipos de datos
* Asociación de tipos
* Arreglos y Diccionarios
*/

//Actividad de Carlos Daniel Suárez García
/*: 
### Actividad de Tipos de datos
A) Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida
*/
var a: Int = 7 //Asignación explícita
var b: Float = 10.5
var c = 14  //Asignación inferida
var texto: String = "Hola mundo, esto es Swift"

/*:
### Asociación de tipos
A) Declara el tipo de dato por asociación para un tipo de dato String
*/
 var name = "Carlos"
//: B) Declara el tipo de dato por asociación para un tipo de dato  Número entero.

 var numero = 23

/*: 
### Arreglos y Diccionarios
A) Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10.
*/
var numeros = [Int]()
numeros.append(1)
numeros.append(2)
numeros.append(3)
numeros.append(4)
numeros.append(5)
numeros.append(6)
numeros.append(7)
numeros.append(8)
numeros.append(9)
numeros.append(10)

print(numeros)
//: B) Crea la variable "diasSemana" de tipo Dictionary con la relación numero:día Ej. 1:"Lunes"
var diasSemana = [Int:String]()
diasSemana = [1:"Lunes", 2:"Martes", 3:"Miércoles", 4:"Jueves", 5:"Viernes", 6:"Sábado",7:"Domingo"]
print(diasSemana)



/*:
### Condicionales y Ciclos
A) Declarar la variable "datos" con los valores [3,6,9,2,4,1]
*/
var datos = [Int]()
datos = [3, 6, 9, 2, 4, 1]
//: B) realizar el recorrido de la variable "datos" con la instrucción "for"
var datos2 = [Int]()
datos2 = [3, 6, 9, 2, 4, 1]
for index in <5{
    print(index)
}

//: C) Encontrar los valores menores a 5





